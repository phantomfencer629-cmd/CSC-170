import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Farmer here.
 * 
 * @Chris Kasper
 * @version 1.0 11/12/2025
 */
public class Farmer extends Actor
{
    /**
     * Act - do whatever the Farmer wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        keyedMovement();
        growCrops();
        catchSheep();
    }
    /**
     * move using WASD including diagonals.
     */
    public void keyedMovement(){
        int x = 0, y = 0;
        if(Greenfoot.isKeyDown("A")){
            x--;
        }
        if(Greenfoot.isKeyDown("S")){
            y++;
        }
        if(Greenfoot.isKeyDown("D")){
            x++;
        }
        if(Greenfoot.isKeyDown("W")){
            y--;
        }
        if(x + y > 0 || x + y < 0 || x - y > 0 || x - y < 0){
            setLocation(getX() + (x * 3), getY() + (y * 3));
        }
    }
    /**
     * remove crop upon collision and spawn more randomly accross the map.
     */
    public void growCrops(){
        if(isTouching(Crops.class)){
            removeTouching(Crops.class);
            for(int i = 0; i < 2; i++){
                int x = Greenfoot.getRandomNumber(getWorld().getWidth());
                int y = Greenfoot.getRandomNumber(getWorld().getHeight());
                getWorld().addObject(new Crops(), x, y);
            }
        }
    }
    /**
     * remove sheep upon collision, catch all to win the game.
     */
    public void catchSheep(){
        if(isTouching(Sheep.class)){
            removeTouching(Sheep.class);
        }
    }
}
