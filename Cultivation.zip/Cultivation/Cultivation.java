import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @Chris Kasper 
 * @version 1.0 11/12/25
 */
public class Cultivation extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Cultivation()
    {    
        // Create a new world with 1300x800 cells with a cell size of 1x1 pixels.
        super(1300, 800, 1);
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Farmer farmer = new Farmer();
        addObject(farmer,691,741);
        for (int i = 0; i < (Greenfoot.getRandomNumber(5) + 5); i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Sheep(), x, y);
        }
        for (int i = 0; i < (Greenfoot.getRandomNumber(10) + 50); i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Crops(), x, y);
        }
    }
}
