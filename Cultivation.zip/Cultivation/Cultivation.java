import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootSound;
/**
 * Write a description of class MyWorld here.
 * 
 * @Chris Kasper 
 * @version 1.0 11/12/25
 */
public class Cultivation extends World
{
    private GreenfootSound backgroundMusic = new GreenfootSound("relaxLoop.mp3");
    private GreenfootSound success = new GreenfootSound("Success.mp3");
    private GreenfootSound failure = new GreenfootSound("Fail.mp3");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public Cultivation()
    {    
        // Create a new world with 1300x800 cells with a cell size of 1x1 pixels.
        super(1300, 800, 1);
        prepare();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Farmer farmer = new Farmer();
        Counter counter = new Counter();
        addObject(farmer,691,741);
        addObject(counter,142, 755); 
        for (int i = 0; i < (Greenfoot.getRandomNumber(5) + 5); i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Sheep(), x, y);
        }
        for (int i = 0; i < (Greenfoot.getRandomNumber(10) + 50); i++) {
            int x = Greenfoot.getRandomNumber(getWidth());
            int y = Greenfoot.getRandomNumber(getHeight());
            addObject(new Crops(), x, y);
        }
    }
    public void act(){
        backgroundMusic.setVolume(50);
        backgroundMusic.playLoop();
        if(getObjects(Sheep.class).isEmpty()){
            backgroundMusic.stop();
            success.play();
            Greenfoot.setWorld(new VictoryScreen());
            Greenfoot.stop();
        }
        if(getObjects(Crops.class).isEmpty()){
            backgroundMusic.stop();
            failure.play();
            Greenfoot.setWorld(new FailScreen());
            Greenfoot.stop();
        }
    }
}
