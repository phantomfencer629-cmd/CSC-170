import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sheep here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sheep extends Animal
{
    /**
     * Act - do whatever the Sheep wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(5);
        randomTurn();
        turnAtEdge();
        eatCrops();
    }
    /**
     * turn randomly while looking for crops.
     */
    public void randomTurn(){
        if(Greenfoot.getRandomNumber(100) <= 20){
            turn(Greenfoot.getRandomNumber(40) - 20);
        }
    }
    /**
     * turn to continue moving when hitting edge of world.
     */
    public void turnAtEdge() {
        if(atWorldEdge()){
            turn(5);
        }
    }
    /**
     * eat any crops upon collision.
     */
    public void eatCrops() {
        if(canSee(Crops.class)) {
            eat(Crops.class);
        }
    }
}
