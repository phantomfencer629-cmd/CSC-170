import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FailScreen here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FailScreen extends World
{

    /**
     * Constructor for objects of class FailScreen.
     * 
     */
    public FailScreen()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1300, 800, 1); 
        GreenfootImage fail = new GreenfootImage(getWidth(), getHeight());
        fail.setColor(Color.BLACK);
        fail.fillRect(0, 0, getWidth(), getHeight());
        setBackground(fail);
        Font f = new Font("SansSerif", 60);
        fail.setFont(f);
        fail.setColor(Color.WHITE);
        String message = "Game Over :(";
        fail.drawString(message, (getWidth() / 2) - message.length() * 20, 
        (getHeight() / 2));
    }
}
